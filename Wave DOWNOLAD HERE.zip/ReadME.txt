Simple disable your anti virus and run Wave.exe
REMEMBER TO RUN AS ADMIN